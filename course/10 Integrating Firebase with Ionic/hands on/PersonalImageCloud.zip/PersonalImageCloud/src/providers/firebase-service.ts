import { Injectable, Inject } from '@angular/core';
import 'rxjs/add/operator/map';
import { FirebaseApp, AngularFire, FirebaseListObservable } from 'angularfire2';


@Injectable()
export class FirebaseService {
  storageRef: any;
  images: FirebaseListObservable<any>;

  constructor(@Inject(FirebaseApp) firebaseApp: any, public af: AngularFire) {
    this.storageRef = firebaseApp.storage().ref('/uploads/');
    this.images = this.af.database.list('/images');
  }
  
  getImages() {
    return this.images;
  }

  uploadImage(img) {
    var d = new Date(),
      n = d.getTime(),
      fileName = n + ".jpg";

    return this.storageRef.child(fileName).putString(img, 'base64').then(snapshot => {
         let downloadURL = snapshot.downloadURL;
         this.images.push({link: downloadURL});
         return true;
      });
  }

}
