import { Camera } from '@ionic-native/camera';
import { FirebaseService } from './../providers/firebase-service';
import { UploadPage } from './../pages/upload/upload';
import { NgModule, ErrorHandler } from '@angular/core';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';
import { AngularFireModule } from 'angularfire2';
import { IonicStorageModule } from '@ionic/storage';
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';

import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

const firebaseConfig = {
    apiKey: "AIzaSyA7SaFb3B6pV-Fg0gdFL1gZ46Jlg7WZko8",
    authDomain: "academy-31145.firebaseapp.com",
    databaseURL: "https://academy-31145.firebaseio.com",
    storageBucket: "academy-31145.appspot.com",
    messagingSenderId: "465970392261"
};

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    UploadPage,
    TabsPage
  ],
  imports: [
    BrowserModule,
    HttpModule,
    IonicModule.forRoot(MyApp),
    AngularFireModule.initializeApp(firebaseConfig),
    IonicStorageModule.forRoot()
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    UploadPage,
    TabsPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    Camera,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    FirebaseService
    ]
})
export class AppModule {}
