import { Component } from '@angular/core';
import { NavController, PopoverController } from 'ionic-angular';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  userResults: Observable<any>;
  selectedFilter = null;

  constructor(public navCtrl: NavController, public http: Http, public popoverCtrl: PopoverController) {
    // https://randomuser.me/api?results=50
    this.userResults = this.getLocalFile();
  }

  getLocalFile(){
    return this.http.get('assets/results.json').
        map(res => res.json().results);
  }

  presentPopover(myEvent) {
    let popover = this.popoverCtrl.create('FilterPopoverPage');
      popover.present({
        ev: myEvent
      });
      popover.onDidDismiss(data => {
        this.selectedFilter = data.filter;
      })
    }

}
