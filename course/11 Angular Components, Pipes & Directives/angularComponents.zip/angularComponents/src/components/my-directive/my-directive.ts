import { Directive, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[my-directive]' // Attribute selector
})
export class MyDirective {

  @Input('specialcolor') highlightColor: string;

  constructor(private el: ElementRef) {}

  ngOnInit() {
    this.el.nativeElement.style.backgroundColor = this.highlightColor;
  }

}
