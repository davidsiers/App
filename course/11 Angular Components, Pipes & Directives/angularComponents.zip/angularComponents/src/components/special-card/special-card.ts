import { Component, Input } from '@angular/core';

@Component({
  selector: 'special-card',
  templateUrl: 'special-card.html'
})
export class SpecialCard {

  @Input('cardtitle') title: string;
  @Input('cardobject') myObj;

  constructor() {

  }

}
