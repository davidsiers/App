import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SpecialCard } from './special-card';

@NgModule({
  declarations: [
    SpecialCard,
  ],
  imports: [
    IonicPageModule.forChild(SpecialCard),
  ],
  exports: [
    SpecialCard
  ]
})
export class SpecialCardModule {}
