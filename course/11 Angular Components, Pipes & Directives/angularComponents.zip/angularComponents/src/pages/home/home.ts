import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  oneObject = {content: 'My Card content whatever'};
  customDate = new Date(1989, 11, 10);
  arrayOfNames = [
    'Albert', 'Adam', 'Josh', 'Max', 'Simon'
  ];

  constructor(public navCtrl: NavController) {

  }

}
