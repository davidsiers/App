import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'customName',
})
export class CustomName implements PipeTransform {
  transform(value: string, ...args) {
    return 'Return a completley different string';
  }
}
