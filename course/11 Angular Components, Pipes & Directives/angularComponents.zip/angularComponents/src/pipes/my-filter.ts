import { Pipe, PipeTransform } from '@angular/core';

/**
 * Generated class for the MyFilter pipe.
 *
 * See https://angular.io/docs/ts/latest/guide/pipes.html for more info on
 * Angular Pipes.
 */
@Pipe({
  name: 'myFilter',
})
export class MyFilter implements PipeTransform {

  transform(items: any[], startingLetter: string): any {
    if (!items || startingLetter === '' || startingLetter == undefined) {
      return items;
    }

    return items.filter(item => item.indexOf(startingLetter) === 0);
  }
}
