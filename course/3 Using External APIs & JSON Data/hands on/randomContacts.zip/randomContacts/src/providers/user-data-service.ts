import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

export class Contact {
  firstname: String;
  lastname: String;
  username: String;
  imageUrl: String;
  phone: String;
  email: String;
  city: String;
  street: String;
  postcode: number;

  constructor(firstname, lastname, username, imageUrl, phone, email, city, street, postcode) {
    this.firstname = firstname;
    this.lastname = lastname;
    this.username = username;
    this.imageUrl = imageUrl;
    this.phone = phone;
    this.email = email;
    this.city = city;
    this.street = street;
    this.postcode = postcode;
  }
}

@Injectable()
export class UserDataService {

  constructor(public http: Http) {
  }

  getUserData(count: number) : Observable<[Contact]> {
      return this.http.get('https://randomuser.me/api/?results=' + count)
      .map(res => res.json())
      .map(data => {
        var result = [];
        for (let obj of data.results) {
          let newContact = new Contact(obj['name']['first'], obj['name']['last'], obj['login']['username'], obj['picture']['large'], obj['phone'], obj['email'], obj['location']['city'], obj['location']['street'], obj['location']['postcode']);
          result.push(newContact);
      }
        return result;
      });
  }

}
