import { DetailsPage } from './../details/details';
import { UserDataService } from './../../providers/user-data-service';
import { Component } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Contact } from './../../providers/user-data-service';

import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  contacts: Observable<[Contact]>;

  constructor(public navCtrl: NavController, public userDataService: UserDataService) {
    this.contacts = userDataService.getUserData(10);
  }

  openDetails(obj: Contact) {
    this.navCtrl.push(DetailsPage, {contact: obj});
  }

}
