import { MapService } from './../../providers/map-service';
import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController, Events } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  @ViewChild('map') mapElement: ElementRef;
  map: any;

  constructor(public navCtrl: NavController, public mapService: MapService, public events: Events) {
    this.events.subscribe('map:focusplace', (place) => {
      this.mapService.focusMap(place);
    });
  }

  ionViewDidLoad() {
    this.map = this.mapService.loadInitialMap(this.mapElement.nativeElement);
  }
}
