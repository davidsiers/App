import { MapService } from './../../providers/map-service';
import { HomePage } from './../home/home';
import { Component } from '@angular/core';
import { NavController, LoadingController, Loading, Events, MenuController } from 'ionic-angular';

@Component({
  selector: 'page-menu',
  templateUrl: 'menu.html'
})
export class MenuPage {
  rootPage: any = HomePage;
  nearbyPlaces = [];
  loader: Loading;

  constructor(public navCtrl: NavController, public mapService: MapService, public loadingCtrl: LoadingController, public events: Events, public menuCtrl: MenuController) {}

  loadAroundMe() {
    this.presentLoading();

    this.mapService.loadPlacesAroundMe().subscribe(data => {
      this.nearbyPlaces = data;
      this.loader.dismiss();
    });
  }

   presentLoading() {
    this.loader = this.loadingCtrl.create({
      content: "Loading"
    });
    this.loader.present();
  }

  focusMap(place) {
    this.menuCtrl.close();
    this.events.publish('map:focusplace', place);
  }

}
